//Erdem Özgür
//Delegate Örnek Gösterimi
//30.05.2018
import UIKit

protocol YemekPisirme{
    func yemekYapmak()
}
struct Anne: YemekPisirme {
    func yemekYapmak()
    {
        print("Pizza geliyor!!")
    }
}   //Protokolümüzdeki fonksiyonumuza yazı ekledik.

// Anne Nesnesini Oluşturma
var anne = Anne()     //Anne yapısını taşıyan anne değişkenini oluşturduk
anne.yemekYapmak()    // "Pizza geliyor!!"

// bebek yapısı oluşturma
struct Bebek {
    var delegate: YemekPisirme? // delegate = özel yetenekleri olan birisi
}
// bebek nesnesi oluşturma
var babe = Bebek()
babe.delegate = anne

babe.delegate?.yemekYapmak()

